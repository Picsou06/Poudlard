const Discord = require('discord.js');
const client = new Discord.Client();

// L'evenement 'ready' va être éxécuté quand le bot va être lancé
client.on('ready', () => {

    console.log('Poudlard est pret!');

});

// L'evenement 'message' va être éxécuté quand un message sera envoyer
// dans un channel ou en DM au bot
client.on('message', message => {

    // Si le message est envoyer en DM au bot
    // Donc on test si le message renvoie une guild
    // Si c'est "false" on retourne
    if (!message.guild) return;

    // Si c'est un bot qui écrit le message
    if (message.author.bot) return;
    
    else if (message.content === 'ping') {
        message.channel.send('pong');
    }

    else if (message.content === '/petrificus ' + message.mentions.members.first()) {
        message.channel.send(message.member.displayName + ' à petrifié ' + message.mentions.members.first() + image);
        // Ton code au dessus va juste renvoyer " $username à petrifié(e) ... " par contre. 
        // Si tu veut envoyer le pseudo de l'author avec un message tu peut faire :
        // message.channel.send(message.member.displayName + 'à petrifié(e) ...');
    }

    else if (message.content === 'uwu') {
        message.channel.send('OwO');
    }

    else if (message.content === 'OwO') {
        message.channel.send('What?');
     }

     else if (message.content === '/lumos ' + message.mentions.members.first()) {
        message.channel.send(message.mentions.members.first() + ' à été illuminer par ' + message.member.displayName +  image2);
     }
     
     else if (message.content === '/wtf ' + message.mentions.members.first()) {
        message.channel.send(message.mentions.members.first() + ' à été illuminer ' + image2);
     }

    else if (message.content === 'What?') {
        message.channel.send('uwu');
    }

    else if (message.content === '/help') {
        message.channel.send('yo tu te debrouille serieux !!');

    // Et j'ai pas compris ta dernière condition
};


})

client.login('NjY3Nzg2OTk5OTA5OTc0MDQ2.Xkfm0A.6UX6zGSCMK-OSP8T66GFkvIA7G4');

var image2 = 'https://media1.tenor.com/images/bad50b998c65a46d589dc3878731771c/tenor.gif';

var image = 'https://www.serieously.com/wp-content/uploads/2018/12/source6.gif';  